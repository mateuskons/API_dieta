const privateKey = "70336239997517e9ba66e28ce78cf4085140fd43852797a27ec340b5d5b905f7"

module.exports = privateKey